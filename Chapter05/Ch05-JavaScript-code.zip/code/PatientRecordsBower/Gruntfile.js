﻿module.exports = function (grunt) {
    grunt.initConfig({
        clean: ["wwwroot/css/*"],
    });
    grunt.loadNpmTasks("grunt-contrib-clean");
};
