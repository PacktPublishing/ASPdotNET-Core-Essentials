﻿/// <binding AfterBuild='stylemaker' ProjectOpened='lesswatcher' />
var gulp = require('gulp');
var gulpless = require('gulp-less')

gulp.task('stylemaker', function () {
    gulp.src("./less/styles.less")
        .pipe(gulpless({ compress: true }))
        .pipe(gulp.dest("./wwwroot/css"));
});

gulp.task('lesswatcher', function () {
    gulp.watch("./less/*.less", ["stylemaker"]);
});
