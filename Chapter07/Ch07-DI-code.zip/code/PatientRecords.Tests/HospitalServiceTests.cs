﻿using PatientRecords.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace PatientRecords.Tests
{
    public class HospitalServiceTests
    {
        public HospitalServiceTests()
        {

        }

        [Fact]
        public void VerifyApptService()
        {
            ApptService apptService = new ApptService();
            var isSuccess = apptService.ScheduleAppt();
            Assert.True(isSuccess);
        }

        [Fact(Skip = "skip this for now")]
        public void VerifySuccess()
        {
            bool isSuccess = false;
            isSuccess = true;
            Assert.True(isSuccess);
        }

        [Theory(Skip = "skip this too")]
        [InlineData(7, 5)]
        public void VerifySuccessWithParams(int n1, int n2)
        {
            Assert.True(n1 > n2);
        }
    }
}
