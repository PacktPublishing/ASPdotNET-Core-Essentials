﻿namespace PatientRecords.Services
{
    public interface IApptService
    {
        bool ScheduleAppt();
    }
}